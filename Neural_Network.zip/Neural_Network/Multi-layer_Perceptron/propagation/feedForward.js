import { loop } from '../tools/loop.js';

const feedforward = (input, model, activation, callback) => {
    const { layers, params } = model;
    let cursor = 0;
    let currentInput = input;

    loop(layers.length - 1, i => {
        const nextInput = [];
        const fanIn = layers[i];
        const fanOut = layers[i + 1];

        loop(fanOut, () => {
            let sum = 0;
            
            loop(fanIn, k => {
                sum += currentInput[k] * params[cursor++];
            });
            
            sum += params[cursor++];
            nextInput.push(sum);
        });

        const activated = activation(nextInput, i);
        callback(activated);
        currentInput = activated;
    });
};

export const forward = (input, model, activation = d => d) => {
    const box = [input];
    feedforward(input, model, activation, (layerOutput) => {
        box.push(layerOutput);
    });
    return box;
};

export const predict = (input, model, activation = d => d) => {
    let finalOutput = input;
    feedforward(input, model, activation, (layerOutput) => {
        finalOutput = layerOutput;
    });
    return finalOutput;
};
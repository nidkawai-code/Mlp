import { xloop } from '../tools/loop.js';
import { arr } from '../tools/arr.js';

export const backward = (error, states, model, dActivation = d => arr(d.length, () => 1)) => {
    const { layers, params } = model;
    const gradients = [];
    let cursor = params.length - 1;
    
    xloop(layers.length - 1, i => {
        const currentError = [...error];
        const nextError = arr(states[i - 1].length);
        const derivative = dActivation(states[i], i, currentError);
        
        const fanIn = layers[i - 1];
        const fanOut = layers[i];
        
        xloop(fanOut - 1, j => {
            const delta = currentError[j] * derivative[j];
            
            gradients[cursor--] = delta;
            
            xloop(fanIn - 1, k => {
                
                gradients[cursor] = states[i - 1][k] * delta;
                
                nextError[k] += delta * params[cursor--];
            });
        });
        
        error = nextError;
    }, 0);
    
    return { gradients, error };
};

import { forward } from '../propagation/feedForward.js';
import { backward } from '../propagation/backpropagation.js';
import { walk } from '../core/walk.js';
import { loop } from '../tools/loop.js';
import { mse } from '../losses/mse.js';
import { sgd } from '../optimizers/sgd.js';

export const train = (inputs, targets, model, action = {}) => {
    const totalData = inputs.length;
    if (totalData === 0) return; // Mencegah loop kosong & NaN division

    let cumulativeLoss = 0;

    loop(totalData, i => {
        const input = inputs[i];
        const target = targets[i];
        
        const states = forward(input, model, action.activation ? action.activation : d => d);
        const prediction = states[states.length - 1];
        
        const { loss, derivative } = action.loss ? action.loss(prediction, target) : mse(prediction, target);
        cumulativeLoss += loss;
        
        const { gradients, error: inputError } = backward(
            derivative, 
            states, 
            model, 
            action.dActivation ? action.dActivation : d => {
                loop(d.length, idx => d[idx] = 1);
                return d;
            }
        );
        
        if (action.onGradient) {
            action.onGradient(gradients, walk, i);
        } else {
            sgd(gradients, model, action.sgdLr ? action.sgdLr : 0.01);
        }

        if (action.onLoss) action.onLoss(loss);
        if (action.onInputError) action.onInputError(inputError);
    });
    
    if (action.onTotalLoss) action.onTotalLoss(cumulativeLoss / totalData);
};

export const epoch = (count, callback) => {
    for (let i = 0; i < count; i++) {
        if (callback(i)) break;
    }
};
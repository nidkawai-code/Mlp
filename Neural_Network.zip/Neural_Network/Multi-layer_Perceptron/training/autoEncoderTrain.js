import { forward } from '../propagation/feedForward.js';
import { backward } from '../propagation/backpropagation.js';
import { walk } from '../core/walk.js';
import { loop } from '../tools/loop.js';
import { mse } from '../losses/mse.js';
import { sgd } from '../optimizers/sgd.js';

export const autoEncoderTrain = (inputs, modelA, modelB, action) => {
    let cumulativeLoss = 0;

    loop(inputs.length, i => {
        const input = inputs[i];
        
        const statesA = forward(input, modelA, action.activationA ? action.activationA : d => d);
        const predictionA = statesA[statesA.length - 1];
        const statesB = forward(predictionA, modelB, action.activationB ? action.activationB : d => d);
        const predictionB = statesB[statesB.length - 1];
        
        const { loss, derivative } = action.loss ? action.loss(predictionB, input) : mse(predictionB, input);
        cumulativeLoss += loss;
        
        const { gradients: gradientsB, error: inputErrorB } = backward(
            derivative, 
            statesB, 
            modelB, 
            action.dActivationB ? action.dActivationB : d => {
                loop(d.length, i => d[i] = 1);
                return d;
            }
        );
        
        const { gradients: gradientsA, error: inputErrorA } = backward(
            inputErrorB,
            statesA, 
            modelA, 
            action.dActivationA ? action.aActivationA : d => {
                loop(d.length, i => d[i] = 1);
                return d;
            }
        );
        
        if(action.onGradientB) {
            action.onGradientB(gradientsB, walk, i);
        } else {
            sgd(gradientsB, modelB, action.sgdLr ? action.sgdLr : 0.01);
        };
        if(action.onGradientA) {
            action.onGradientA(gradientsA, walk, i);
        } else {
            sgd(gradientsA, modelA, action.sgdLr ? action.sgdLr : 0.01);
        };
        if(action.onLoss) action.onLoss(loss);
        if(action.onInputError) action.onInputError(inputErrorA);
    });

    if(action.onTotalLoss) action.onTotalLoss(cumulativeLoss / inputs.length);
};

import { loop } from '../tools/loop.js';
import { arr } from '../tools/arr.js';

export const simple = layers => {
    let size = 0;
    
    loop(layers.length - 1, i => {
        const current = layers[i];
        const next = layers[i + 1];
        
        size += (current * next) + next;
    });

    return arr(size, () => Math.random() * 2 - 1);
};
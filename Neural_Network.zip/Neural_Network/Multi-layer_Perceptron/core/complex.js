import { loop } from '../tools/loop.js';

export const complex = (layers, initWeight = () => Math.random() * 2 - 1, initBias = () => 0) => {
    const params = [];
    
    loop(layers.length - 1, i => {
        const fanIn = layers[i];
        const fanOut = layers[i + 1];
        
        loop(fanOut, () => {
            loop(fanIn, () => {
                params.push(initWeight(fanIn, fanOut, i));
            });
            params.push(initBias(i));
        });
    });

    return params;
};
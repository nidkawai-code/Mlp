import { loop } from '../tools/loop.js';

export const walk = (model, callback) => {
    const { layers, params } = model;
    let cursor = 0;
    
    loop(layers.length - 1, i => {
        const fanIn = layers[i];
        const fanOut = layers[i + 1];
        
        loop(fanOut, () => {
            
            loop(fanIn, () => {
                callback(params[cursor], cursor); cursor++;
            });
            
            callback(0, cursor); cursor++;
        });
    });
};
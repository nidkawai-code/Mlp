import { basic as activationsBasic } from './plugins/activations/basic/basic.js';
import { softmax } from './plugins/activations/softmax/softmax.js';
import { basic as losses } from './plugins/losses/basic/basic.js';
import { basic as initializers } from './plugins/initializers/basic/basic.js';
import { momentum, data as dataMomentum } from './plugins/optimizers/momentum/momentum.js';
import { adam, data as dataAdam } from './plugins/optimizers/adam/adam.js';
import { rmsProp, data as dataRmsProp } from './plugins/optimizers/RMSProp/rmsProp.js';
import { adaGrad, data as dataAdaGrad } from './plugins/optimizers/adaGrad/adaGrad.js';
import { adaDelta, data as dataAdaDelta } from './plugins/optimizers/adaDelta/adaDelta.js';
import { basic as regularizers } from './plugins/regularizers/basic/basic.js';

const optimizers = {
    momentum, dataMomentum,
    adam, dataAdam,
    rmsProp, dataRmsProp,
    adaGrad, dataAdaGrad,
    adaDelta, dataAdaDelta
};

const { relu, leaky, sigmoid, tanh } = activationsBasic;
const activations = {
    relu, leaky,
    sigmoid, tanh,
    softmax
};
export const plugins = {
    activations,
    losses,
    initializers,
    optimizers,
    regularizers
};


import { loop, xloop } from './tools/loop.js';
import { arr } from './tools/arr.js';
import { json } from './tools/json.js';
import { saveJs } from './tools/saveJs.js';
import { load } from './tools/load.js';

import { simple } from './core/simple.js';
import { complex } from './core/complex.js';
import { walk } from './core/walk.js';

import { forward, predict } from './propagation/feedForward.js';
import { backward } from './propagation/backpropagation.js';

import { train, epoch } from './training/train.js';
import { autoEncoderTrain } from './training/autoEncoderTrain.js';
import { sgd } from './optimizers/sgd.js';

import { relu, dRelu } from './activations/relu.js';
import { mse } from './losses/mse.js';

export const p = {
    loop, xloop, arr, json,
    saveJs, load,
    
    simple, complex, walk,
    
    forward, predict, backward,
    
    train, autoEncoderTrain, epoch,
    
    sgd,
    
    relu, dRelu,
    mse
};
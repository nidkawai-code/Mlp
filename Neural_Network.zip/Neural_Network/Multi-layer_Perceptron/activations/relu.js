import { loop } from '../tools/loop.js';

export const relu = data => {
    loop(data.length, i => {
        if (data[i] < 0) data[i] = 0;
    });
    return data;
};

export const dRelu = data => {
    loop(data.length, i => {
        data[i] = data[i] > 0 ? 1 : 0;
    });
    return data;
};
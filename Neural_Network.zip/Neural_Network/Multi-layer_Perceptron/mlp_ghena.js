import { p } from './index.js';

export const mlp = config => {
    const { 
        layers, 
        activations, 
        dActivations, 
        randomInitializers, 
        biasInitializers 
    } = config;

    class Main {
        constructor() {
            this.model = {
                layers: layers,
                params: randomInitializers === 'simple' 
                    ? p.simple(layers) 
                    : p.complex(layers, (fanIn, fanOut, l) => {
                        const initFunc = Array.isArray(randomInitializers) 
                            ? randomInitializers[l] 
                            : randomInitializers;
                        return initFunc(fanIn, fanOut);
                    }, (l) => {
                        if (!biasInitializers) return 0;
                        return Array.isArray(biasInitializers) 
                            ? biasInitializers[l]() 
                            : biasInitializers();
                    })
            };
        }
        
        predict(input) {
            return p.predict(input, this.model, (data, i) => {
                return activations[i](data);
            });
        }
        
        train(dataset, epochs, action = {}) {
            const inputs = dataset.xs ?? dataset.inputs;
            const targets = dataset.ys ?? dataset.targets;
            
            p.epoch(epochs, e => {
                let currentLoss = 0;
                
                p.train(inputs, targets, this.model, {
                    
                    activation: (out, i) => activations[i](out),
                    
                    dActivation: (act, i, err) => {
                        const fn = dActivations[i - 1];
                        return fn ? fn(act, err) : err;
                    },
                    
                    loss: action.loss,
                    sgdLr: action.sgdLr,
                    onGradient: action.onGradient,
                    onLoss: action.onLoss,
                    onInputError: action.onInputError,
                    onTotalLoss: loss => { currentLoss = loss; }
                });
                if (action.onEpoch && action.onEpoch(e, currentLoss) === true) return true;
            });
        }
    }

    return new Main();
};

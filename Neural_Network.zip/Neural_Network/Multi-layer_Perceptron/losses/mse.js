import { loop } from '../tools/loop.js';

export const mse = (prediction, target) => {
    let totalError = 0;
    const derivative = [];
    const n = prediction.length;

    loop(n, i => {
        const error = prediction[i] - target[i];
        
        totalError += error * error;
        
        derivative.push((2 * error) / n);
    });

    return { 
        loss: totalError / n, 
        derivative 
    };
};
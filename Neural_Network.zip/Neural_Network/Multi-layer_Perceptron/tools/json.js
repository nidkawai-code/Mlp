const { stringify: str, parse: pse } = JSON;

export const json = { str, pse };
export const load = model => {
    if(model.modelA && model.modelB) {
        model.predictA = input => {
            const act = (o, l) => model.actA[l](o);
            const pred = model._predict(input, model.modelA, act);
            return pred;
        };
        model.predictB = input => {
            const act = (o, l) => model.actB[l](o);
            const pred = model._predict(input, model.modelB, act);
            return pred;
        };
    } else {
        model.predict = input => {
            const act = (o, l) => model.act[l](o);
            const pred = model._predict(input, model.model, act);
            return pred;
        };
    };
    return model;
};
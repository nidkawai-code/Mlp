export const arr = (val, fn = () => 0) => {
    return Array.from({ length: val }, (_, i) => fn(i));
};
export const saveJs = (fileName, content) => {
    
    const jsContent = `export const ${fileName} = ${content};`;
    
    const blob = new Blob([jsContent], { type: 'text/javascript;charset=utf-8' });
    
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.js`; // Ekstensi otomatis .js
    
    link.click();
    
    URL.revokeObjectURL(url);
};

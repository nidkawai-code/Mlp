export const loop = (iter, fn, start = 0) => {
    for (let i = start; i < iter; i++) {
        fn(i);
    }
};

export const xloop = (start, fn, end = -1) => {
    for (let i = start; i > end; i--) {
        fn(i);
    }
};
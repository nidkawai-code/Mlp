export const basic = (grad, weight, type = 'l2', lambda = 0.001) => {
    if (type === 'l1') {
        
        const sign = weight > 0 ? 1 : (weight < 0 ? -1 : 0);
        return grad + (lambda * sign);
    } 
    
    if (type === 'l2') {
        
        return grad + (lambda * weight);
    }

    return grad;
};
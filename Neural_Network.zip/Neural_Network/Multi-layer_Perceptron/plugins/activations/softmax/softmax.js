export const softmax = {
    f: d => {
        let max = -Infinity;
        for (let i = 0; i < d.length; i++) if (d[i] > max) max = d[i];
        
        let sum = 0;
        for (let i = 0; i < d.length; i++) {
            d[i] = Math.exp(d[i] - max);
            sum += d[i];
        }
        for (let i = 0; i < d.length; i++) d[i] /= sum;
        return d;
    },
    
    b: (a, err) => {
        
        let dot = 0;
        for (let i = 0; i < a.length; i++) {
            dot += a[i] * err[i];
        }
        
        for (let i = 0; i < err.length; i++) {
            err[i] = a[i] * (err[i] - dot);
        }
        
        for (let i = 0; i < a.length; i++) {
            a[i] = 1;
        }

        return a;
    },
    
    ce: d => {
        for (let i = 0; i < d.length; i++) d[i] = 1;
        return d;
    }
};
const relu = {
    f: d => {
        for (let i = 0; i < d.length; i++) if (d[i] < 0) d[i] = 0;
        return d;
    },
    b: d => {
        for (let i = 0; i < d.length; i++) d[i] = d[i] > 0 ? 1 : 0;
        return d;
    }
};

const lRelu = {
    f: (d, a = 0.01) => {
        for (let i = 0; i < d.length; i++) if (d[i] < 0) d[i] *= a;
        return d;
    },
    b: (d, a = 0.01) => {
        for (let i = 0; i < d.length; i++) d[i] = d[i] > 0 ? 1 : a;
        return d;
    }
};

const sigm = {
    f: d => {
        for (let i = 0; i < d.length; i++) d[i] = 1 / (1 + Math.exp(-d[i]));
        return d;
    },
    b: d => {
        for (let i = 0; i < d.length; i++) d[i] = d[i] * (1 - d[i]);
        return d;
    },
   
    bce: d => {
        for (let i = 0; i < d.length; i++) d[i] = 1; 
        return d;
    }
};

const tanh = {
    f: d => {
        for (let i = 0; i < d.length; i++) d[i] = Math.tanh(d[i]);
        return d;
    },
    b: d => {
        for (let i = 0; i < d.length; i++) d[i] = 1 - (d[i] * d[i]);
        return d;
    }
};

export const basic = { relu, leaky: lRelu, sigmoid: sigm, tanh };
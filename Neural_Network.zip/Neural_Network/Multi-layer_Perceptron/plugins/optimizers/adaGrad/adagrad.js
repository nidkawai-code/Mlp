class DataAdaGrad {
    constructor( config = {} ) {
        const { lr, epsilon } = config;
        this.lr = lr || 0.01;
        this.epsilon =  epsilon || 1e-8;
        this.cache = {
            sumSqGrad: null
        };
    }
};

export const data = config => new DataAdaGrad(config);

export const adaGrad = (grad, model, dataAdaGrad = new DataAdaGrad()) => {
    const { lr, epsilon, cache } = dataAdaGrad;

    if (!cache.sumSqGrad) {
        cache.sumSqGrad = new Array(model.params.length).fill(0);
    }

    for (let i = 0; i < model.params.length; i++) {
        cache.sumSqGrad[i] += grad[i] * grad[i];
        
        model.params[i] -= (lr * grad[i]) / (Math.sqrt(cache.sumSqGrad[i]) + epsilon);
    }
};
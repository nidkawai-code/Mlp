class DataMomentum {
    constructor( config = {} ) {
        const { lr, mu } = config;
        this.lr = lr || 0.01;
        this.mu = mu || 0.9;
        this.cache = {
            velocity: null
        };
        return this;
    }
};

export const data = config => new DataMomentum(config);

export const momentum = (grad, model, dataMomentum = new DataMomentum()) => {
    const { lr, mu, cache } = dataMomentum;

    if (!cache.velocity) {
        cache.velocity = new Array(model.params.length).fill(0);
    }
    
    for (let i = 0; i < model.params.length; i++) {
        cache.velocity[i] = (mu * cache.velocity[i]) - (lr * grad[i]);
        
        model.params[i] += cache.velocity[i];
    }
};
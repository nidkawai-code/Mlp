class DataAdaDelta {
    constructor( config = {} ) {
        const { lr, decay, epsilon } = config;
        this.lr = lr || 0.01;
        this.decay = decay || 0.95;
        this.epsilon = epsilon || 1e-8;
        this.cache = {
            gradSqr: null,
            updateSqr: null
        };
    }
};

export const data = config => new DataAdaDelta(config);

export const adaDelta = (grad, model, dataAdaDelta = new DataAdaDelta()) => {
    const { lr, decay, epsilon, cache } = dataAdaDelta;

    if (!cache.gradSqr || !cache.updateSqr) {
        cache.gradSqr = new Array(model.params.length).fill(0);
        cache.updateSqr = new Array(model.params.length).fill(0);
    }

    for (let i = 0; i < model.params.length; i++) {
        cache.gradSqr[i] = (decay * cache.gradSqr[i]) + (1 - decay) * (grad[i] * grad[i]);
        
        const step = Math.sqrt((cache.updateSqr[i] + epsilon) / (cache.gradSqr[i] + epsilon)) * grad[i];
        
        model.params[i] -= lr * step;
        
        cache.updateSqr[i] = (decay * cache.updateSqr[i]) + (1 - decay) * (step * step);
    }
};
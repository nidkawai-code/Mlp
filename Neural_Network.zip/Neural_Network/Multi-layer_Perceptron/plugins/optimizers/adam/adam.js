class DataAdam {
    constructor( config = {} ) {
        const { lr, beta1, beta2, epsilon } = config;
        this.lr = lr || 0.01;
        this.beta1 = beta1 || 0.9;
        this.beta2 = beta2 || 0.99;
        this.epsilon = epsilon || 1e-8;
        this.cache = {
            momentum: null,
            velocity: null,
            timeStep: 0
        };
    }
};

export const data = config => new DataAdam(config);

export const adam = (grad, model, dataAdam = new DataAdam()) => {
    const { lr, beta1, beta2, epsilon, cache } = dataAdam;
    
    if (!cache.momentum || !cache.velocity) {
        cache.momentum = new Array(model.params.length).fill(0);
        cache.velocity = new Array(model.params.length).fill(0);
    }
    
    cache.timeStep += 1;
    
    const bias1 = 1 - Math.pow(beta1, cache.timeStep);
    const bias2 = 1 - Math.pow(beta2, cache.timeStep);
    
    for (let i = 0; i < model.params.length; i++) {
        cache.momentum[i] = beta1 * cache.momentum[i] + (1 - beta1) * grad[i];
        
        cache.velocity[i] = beta2 * cache.velocity[i] + (1 - beta2) * (grad[i] * grad[i]);
        
        const mHat = cache.momentum[i] / bias1;
        const vHat = cache.velocity[i] / bias2;
        
        model.params[i] -= (lr * mHat) / (Math.sqrt(vHat) + epsilon);
    }
};
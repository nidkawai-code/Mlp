class DataRmsProp {
    constructor( config = {} ) {
        const { lr, decay, epsilon } = config;
        this.lr = lr || 0.01;
        this.decay = decay || 0.9;
        this.epsilon = 1e-8;
        this.cache = {
            velocity: null
        };
    }
};

export const data = config => new DataRmsProp(config);

export const rmsProp = (grad, model, dataRMSProp = new DataRmsProp()) => {
    const { lr, decay, epsilon, cache } = dataRMSProp;
    
    if (!cache.velocity) {
        cache.velocity = new Array(model.params.length).fill(0);
    }
    
    for (let i = 0; i < model.params.length; i++) {
        cache.velocity[i] = (decay * cache.velocity[i]) + (1 - decay) * (grad[i] * grad[i]);
        
        model.params[i] -= (lr * grad[i]) / (Math.sqrt(cache.velocity[i]) + epsilon);
    }
};
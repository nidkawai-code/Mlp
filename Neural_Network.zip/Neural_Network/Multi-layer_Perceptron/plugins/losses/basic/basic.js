export const basic = {
    mse: (prediction, target) => {
        let totalError = 0;
        const n = prediction.length;
        const derivative = new Array(n);

        for (let i = 0; i < n; i++) {
            const error = prediction[i] - target[i];
            totalError += error * error;
            derivative[i] = (2 * error) / n;
        }

        return { 
            loss: totalError / n, 
            derivative 
        };
    },
    
    mae: (prediction, target) => {
        let totalError = 0;
        const n = prediction.length;
        const derivative = new Array(n);

        for (let i = 0; i < n; i++) {
            const error = prediction[i] - target[i];
            totalError += Math.abs(error);
            
            derivative[i] = error > 0 ? 1 / n : (error < 0 ? -1 / n : 0);
        }

        return { 
            loss: totalError / n, 
            derivative 
        };
    },
    
    bce: (prediction, target) => {
        let totalLoss = 0;
        const n = prediction.length;
        const derivative = new Array(n);
        const eps = 1e-15;

        for (let i = 0; i < n; i++) {
            const pred = Math.max(eps, Math.min(1 - eps, prediction[i]));
            const t = target[i];
            
            totalLoss -= t * Math.log(pred) + (1 - t) * Math.log(1 - pred);
            
            derivative[i] = pred - t;
        }

        return { 
            loss: totalLoss / n, 
            derivative 
        };
    },
    
    ce: (prediction, target) => {
        let totalLoss = 0;
        const n = prediction.length;
        const derivative = new Array(n);
        const eps = 1e-15;

        for (let i = 0; i < n; i++) {
            const pred = Math.max(eps, Math.min(1 - eps, prediction[i]));
            const t = target[i];
            
            totalLoss -= t * Math.log(pred);
            
            derivative[i] = pred - t;
        }

        return { 
            loss: totalLoss / n, 
            derivative 
        };
    }
};
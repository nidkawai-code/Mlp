export const basic = {
    classic: () => Math.random() * 2 - 1,
    
    small: () => (Math.random() - 0.5) * 0.01,
    
    xavier: (fanIn, fanOut) => {
        const limit = Math.sqrt(6 / (fanIn + fanOut));
        return Math.random() * 2 * limit - limit;
    },
    
    he: (fanIn) => {
        const std = Math.sqrt(2 / fanIn);
        
        const u = 1 - Math.random();
        const v = 1 - Math.random();
        const normal = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
        return normal * std;
    },
    
    zero: () => 0
};
import { p } from './index.js';

export const autoEncoder = config => {
    const { 
        layersA, activationsA, dActivationsA, randomInitializersA, biasInitializersA,
        layersB, activationsB, dActivationsB, randomInitializersB, biasInitializersB
    } = config;

    class Main {
        constructor() {
            this.modelA = {
                layers: layersA,
                params: randomInitializersA === 'simple' ? p.simple(layersA) : p.complex(layersA, (fanIn, fanOut, l) => {
                    const initFunc = Array.isArray(randomInitializersA) ? randomInitializersA[l] : randomInitializersA;
                    return initFunc(fanIn, fanOut);
                }, (l) => biasInitializersA ? (Array.isArray(biasInitializersA) ? biasInitializersA[l]() : biasInitializersA()) : 0)
            };
            
            this.modelB = {
                layers: layersB,
                params: randomInitializersB === 'simple' ? p.simple(layersB) : p.complex(layersB, (fanIn, fanOut, l) => {
                    const initFunc = Array.isArray(randomInitializersB) ? randomInitializersB[l] : randomInitializersB;
                    return initFunc(fanIn, fanOut);
                }, (l) => biasInitializersB ? (Array.isArray(biasInitializersB) ? biasInitializersB[l]() : biasInitializersB()) : 0)
            };
        }

        predictA(input) {
            return p.predict(input, this.modelA, (data, i) => activationsA[i](data));
        }

        predictB(input) {
            return p.predict(input, this.modelB, (data, i) => activationsB[i](data));
        }

        train(dataset, epochs, action) {
            p.epoch(epochs, e => {
                let currentLoss = 0;

                p.autoEncoderTrain(dataset, this.modelA, this.modelB, {
                    activationA: (out, i) => activationsA[i](out),
                    activationB: (out, i) => activationsB[i](out),
                    dActivationA: (act, i, err) => dActivationsA[i - 1](act, err),
                    dActivationB: (act, i, err) => dActivationsB[i - 1](act, err),
                    loss: action.loss,
                    sgdLr: action.sgdLr,
                    onGradientA: action.onGradientA,
                    onGradientB: action.onGradientB,
                    onLoss: action.onLoss,
                    onInputError: action.onInputError,
                    onTotalLoss: loss => { currentLoss = loss; }
                });

                if (action.onEpoch && action.onEpoch(currentLoss, e) === true) return true;
            });
        }
    }

    return new Main();
};

import { loop } from '../tools/loop.js';

export const sgd = (gradients, model, lr) => {
    const { params } = model;
    
    loop(gradients.length, i => {
        params[i] -= gradients[i] * lr;
    });
};
import { ghena } from './Multi-layer_Perceptron/ghena.js';
import { plugins } from './Multi-layer_Perceptron/plugins.js';

const { def, mlp, autoEncoder} = ghena;
export const gn = {
    libraryName: 'Ghena',
    version: '0.1',
    dateExport: '2, 19/05/2026',
    author: 'Thenma',
    def, mlp, autoEncoderMlp: autoEncoder, plugins
};
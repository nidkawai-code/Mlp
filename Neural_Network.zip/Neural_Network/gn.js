import { gn as _gn } from './ghena.export.version.0.1.js';
export const gn = _gn;